VPNBook — MSN Collector package
================================
Username and password are already embedded inside every .ovpn file
(<auth-user-pass> block, OpenVPN 2.4+). Just import and connect —
no manual login is needed.

Older OpenVPN clients: keep vpnbook_credentials.txt next to the .ovpn
file and change the line `auth-user-pass` to:
    auth-user-pass vpnbook_credentials.txt

The password changes every 1-2 weeks — re-download the package when
connections stop working.
