MSN Collector — OpenVPN package
================================
Every .ovpn file in this package is standalone: wherever a login is
required, the username and password are already embedded inside the file
itself (<auth-user-pass> block, OpenVPN 2.4+). Just import and connect —
no manual login is needed.

Files are also available individually (openvpn/<name>.ovpn), and the
metadata of all servers lives in openvpn.json.

Shared credentials rotate every 1-2 weeks — re-download the package when
connections stop working.
